from django.shortcuts import render, HttpResponse
from django.contrib import messages
from users.models import UserRegistrationModel, PropertyRegisterModel


# Create your views here.
def AdminLoginCheck(request):
    if request.method == 'POST':
        usrid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("User ID is = ", usrid)
        if usrid == 'admin' and pswd == 'admin':
            return render(request, 'admins/AdminHome.html')

        else:
            messages.success(request, 'Please Check Your Login Details')
    return render(request, 'AdminLogin.html', {})


def AdminHome(request):
    return render(request, 'admins/AdminHome.html')


def SROHome(request):
    return render(request, 'sro/sroHome.html')


def RegisterUsersView(request):
    data = UserRegistrationModel.objects.all()
    return render(request, 'admins/viewregisterusers.html', {'data': data})


def ActivaUsers(request):
    if request.method == 'GET':
        id = request.GET.get('uid')
        status = 'activated'
        print("PID = ", id, status)
        UserRegistrationModel.objects.filter(id=id).update(status=status)
        data = UserRegistrationModel.objects.all()
        return render(request, 'admins/viewregisterusers.html', {'data': data})


def deActivaUsers(request):
    if request.method == 'GET':
        id = request.GET.get('uid')
        status = 'waiting'
        print("PID = ", id, status)
        UserRegistrationModel.objects.filter(id=id).update(status=status)
        data = UserRegistrationModel.objects.all()
        return render(request, 'admins/viewregisterusers.html', {'data': data})


def AdminViewProperty(request):
    data = PropertyRegisterModel.objects.filter(status='Accepted')
    return render(request, 'admins/adminViewProperty.html', {'data': data})


def sroLoginCheck(request):
    if request.method == 'POST':
        usrid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("User ID is = ", usrid)
        if usrid == 'sro' and pswd == 'sro':
            return render(request, 'sro/sroHome.html')

        else:
            messages.success(request, 'Please Check Your Login Details')
    return render(request, 'SROLogin.html', {})


def sroviewProperties(request):
    data = PropertyRegisterModel.objects.all()
    return render(request, 'sro/viewregisterproperties.html', {'data': data})


def sroAcceptProperty(request):
    id = request.GET.get('uid')
    status = 'Accepted'
    PropertyRegisterModel.objects.filter(id=id).update(status=status)
    data = PropertyRegisterModel.objects.all()
    return render(request, 'sro/viewregisterproperties.html', {'data': data})
